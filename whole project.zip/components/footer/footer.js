import { addUser } from "@/store/userSection";
import { useDispatch, useSelector } from "react-redux"

export function Footer(){

  let dispatch = useDispatch();

  const some = useSelector(function(store){
    return store.abc;
  });

  const sendData = ()=>{

    let newFruit =  prompt("Enter fruit name");
    dispatch( addUser(newFruit) );

  }

    return  <div className="container">

      <button onClick={sendData}>Send fruit</button>

    <footer className="row row-cols-1 row-cols-sm-2 row-cols-md-5 py-5 my-5 border-top">
    {" "}

    <h1>{
      some.data[1]
      }</h1>
    <div className="col mb-3">
      {" "}
      <a
        href="/"
        className="d-flex align-items-center mb-3 link-body-emphasis text-decoration-none"
        aria-label="Bootstrap"
      >
        {" "}
        <svg className="bi me-2" width={40} height={32} aria-hidden="true">
          <use xlinkHref="#bootstrap" />
        </svg>{" "}
      </a>{" "}
      <p className="text-body-secondary">© 2025</p>{" "}
    </div>{" "}
    <div className="col mb-3" />{" "}
    <div className="col mb-3">
      {" "}
      <h5>Section</h5>{" "}
      <ul className="nav flex-column">
        {" "}
        <li className="nav-item mb-2">
          <a href="#" className="nav-link p-0 text-body-secondary">
            Home
          </a>
        </li>{" "}
        <li className="nav-item mb-2">
          <a href="#" className="nav-link p-0 text-body-secondary">
            Features
          </a>
        </li>{" "}
        <li className="nav-item mb-2">
          <a href="#" className="nav-link p-0 text-body-secondary">
            Pricing
          </a>
        </li>{" "}
        <li className="nav-item mb-2">
          <a href="#" className="nav-link p-0 text-body-secondary">
            FAQs
          </a>
        </li>{" "}
        <li className="nav-item mb-2">
          <a href="#" className="nav-link p-0 text-body-secondary">
            About
          </a>
        </li>{" "}
      </ul>{" "}
    </div>{" "}
    <div className="col mb-3">
      {" "}
      <h5>Section</h5>{" "}
      <ul className="nav flex-column">
        {" "}
        <li className="nav-item mb-2">
          <a href="#" className="nav-link p-0 text-body-secondary">
            Home
          </a>
        </li>{" "}
        <li className="nav-item mb-2">
          <a href="#" className="nav-link p-0 text-body-secondary">
            Features
          </a>
        </li>{" "}
        <li className="nav-item mb-2">
          <a href="#" className="nav-link p-0 text-body-secondary">
            Pricing
          </a>
        </li>{" "}
        <li className="nav-item mb-2">
          <a href="#" className="nav-link p-0 text-body-secondary">
            FAQs
          </a>
        </li>{" "}
        <li className="nav-item mb-2">
          <a href="#" className="nav-link p-0 text-body-secondary">
            About
          </a>
        </li>{" "}
      </ul>{" "}
    </div>{" "}
    <div className="col mb-3">
      {" "}
      <h5>Section</h5>{" "}
      <ul className="nav flex-column">
        {" "}
        <li className="nav-item mb-2">
          <a href="#" className="nav-link p-0 text-body-secondary">
            Home
          </a>
        </li>{" "}
        <li className="nav-item mb-2">
          <a href="#" className="nav-link p-0 text-body-secondary">
            Features
          </a>
        </li>{" "}
        <li className="nav-item mb-2">
          <a href="#" className="nav-link p-0 text-body-secondary">
            Pricing
          </a>
        </li>{" "}
        <li className="nav-item mb-2">
          <a href="#" className="nav-link p-0 text-body-secondary">
            FAQs
          </a>
        </li>{" "}
        <li className="nav-item mb-2">
          <a href="#" className="nav-link p-0 text-body-secondary">
            About
          </a>
        </li>{" "}
      </ul>{" "}
    </div>{" "}
  </footer>{" "}
</div>

}